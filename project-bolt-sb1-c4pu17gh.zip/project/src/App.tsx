import { useState } from 'react';
import {
  Zap,
  Phone,
  MapPin,
  Star,
  Shield,
  Clock,
  CheckCircle,
  Menu,
  X,
  Home,
  Building2,
  Lightbulb,
  Gauge,
  Send,
} from 'lucide-react';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const services = [
    {
      icon: Home,
      title: 'Residential Electrical Work',
      description: 'Complete home electrical solutions including wiring, repairs, installations, and safety inspections for your peace of mind.',
    },
    {
      icon: Building2,
      title: 'Commercial Electrical Services',
      description: 'Professional electrical services for businesses, offices, and commercial properties tailored to your operational needs.',
    },
    {
      icon: Lightbulb,
      title: 'Lighting Installation & Repair',
      description: 'Indoor and outdoor lighting solutions, from recessed lighting to landscape lighting that enhances your property.',
    },
    {
      icon: Gauge,
      title: 'Panel Upgrades',
      description: 'Electrical panel upgrades and replacements to meet modern power demands and improve your home safety.',
    },
  ];

  const testimonials = [
    {
      text: 'I highly recommend them to anyone looking for quality electrical services!',
      author: 'Sarah M.',
      location: 'Livonia, MI',
    },
    {
      text: 'The best, he did a lot of work in my house, my house shines in every room.',
      author: 'Michael R.',
      location: 'Westland, MI',
    },
    {
      text: 'Great experience from start to finish.',
      author: 'Jennifer T.',
      location: 'Plymouth, MI',
    },
  ];

  const whyChooseUs = [
    { icon: Clock, title: '6+ Years Experience', description: 'Trusted expertise serving Wayne County' },
    { icon: Star, title: '5.0 Star Rating', description: 'Consistently top-rated by our customers' },
    { icon: CheckCircle, title: 'Free Estimates', description: 'No-obligation quotes for every project' },
    { icon: Shield, title: 'Licensed & Reliable', description: 'Fully licensed, insured professionals' },
  ];

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2">
              <div className="bg-navy-900 p-2 rounded-lg">
                <Zap className="w-6 h-6 text-gold-400" />
              </div>
              <span className="font-display font-bold text-xl text-navy-900">TiaraLine Electric</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <a href="#services" className="text-navy-700 hover:text-navy-900 font-medium transition-colors">Services</a>
              <a href="#about" className="text-navy-700 hover:text-navy-900 font-medium transition-colors">Why Us</a>
              <a href="#testimonials" className="text-navy-700 hover:text-navy-900 font-medium transition-colors">Reviews</a>
              <a href="#contact" className="text-navy-700 hover:text-navy-900 font-medium transition-colors">Contact</a>
            </div>

            <div className="hidden md:flex items-center gap-4">
              <a href="tel:7343733742" className="flex items-center gap-2 text-navy-900 font-semibold">
                <Phone className="w-5 h-5 text-gold-500" />
                (734) 373-3742
              </a>
              <a
                href="#contact"
                className="bg-gold-500 hover:bg-gold-600 text-navy-900 font-semibold px-5 py-2.5 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
              >
                Free Estimate
              </a>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-navy-900"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-4 py-4 space-y-4">
              <a href="#services" className="block text-navy-700 font-medium" onClick={() => setMobileMenuOpen(false)}>Services</a>
              <a href="#about" className="block text-navy-700 font-medium" onClick={() => setMobileMenuOpen(false)}>Why Us</a>
              <a href="#testimonials" className="block text-navy-700 font-medium" onClick={() => setMobileMenuOpen(false)}>Reviews</a>
              <a href="#contact" className="block text-navy-700 font-medium" onClick={() => setMobileMenuOpen(false)}>Contact</a>
              <div className="pt-4 border-t">
                <a href="tel:7343733742" className="flex items-center gap-2 text-navy-900 font-semibold">
                  <Phone className="w-5 h-5 text-gold-500" />
                  (734) 373-3742
                </a>
                <a
                  href="#contact"
                  className="mt-3 block w-full text-center bg-gold-500 hover:bg-gold-600 text-navy-900 font-semibold px-5 py-3 rounded-lg transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Free Estimate
                </a>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 bg-gradient-to-br from-navy-950 via-navy-900 to-navy-800 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gold-400 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-gold-500 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-navy-800/50 border border-navy-700 rounded-full px-4 py-2 mb-6">
              <Zap className="w-4 h-4 text-gold-400" />
              <span className="text-navy-200 text-sm font-medium">Serving Wayne County, Michigan</span>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Powering Homes & Businesses Across{' '}
              <span className="text-gold-400">Wayne County</span>
            </h1>

            <p className="text-lg sm:text-xl text-navy-200 mb-8 leading-relaxed">
              With over 6 years of experience, TiaraLine Electric delivers reliable, high-quality electrical services for residential and commercial properties. Licensed, trusted, and committed to your safety.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="tel:7343733742"
                className="inline-flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-900 font-semibold px-8 py-4 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Phone className="w-5 h-5" />
                Call Now
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/30 font-semibold px-8 py-4 rounded-lg transition-all duration-200"
              >
                Get Free Estimate
              </a>
            </div>

            <div className="mt-12 flex items-center gap-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-gold-400 fill-gold-400" />
                ))}
                <span className="ml-2 text-white font-semibold">5.0</span>
              </div>
              <div className="h-6 w-px bg-navy-700"></div>
              <span className="text-navy-300">100+ Happy Customers</span>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 120L1440 120L1440 0C1440 0 1140 80 720 80C300 80 0 0 0 0L0 120Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-wider mb-3">Our Services</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-navy-900 mb-4">
              Complete Electrical Solutions
            </h2>
            <p className="text-navy-600 max-w-2xl mx-auto">
              From simple repairs to complex installations, we provide comprehensive electrical services for homes and businesses throughout Wayne County.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div
                key={index}
                className="group bg-white border border-navy-100 rounded-2xl p-6 hover:border-gold-300 hover:shadow-xl transition-all duration-300"
              >
                <div className="bg-navy-900 group-hover:bg-gold-500 p-4 rounded-xl inline-block mb-5 transition-colors duration-300">
                  <service.icon className="w-7 h-7 text-gold-400 group-hover:text-navy-900 transition-colors duration-300" />
                </div>
                <h3 className="font-display font-semibold text-lg text-navy-900 mb-3">{service.title}</h3>
                <p className="text-navy-600 text-sm leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="about" className="py-20 lg:py-28 bg-navy-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-wider mb-3">Why Choose Us</span>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-navy-900 mb-6">
                Your Trusted Local Electrician
              </h2>
              <p className="text-navy-600 mb-8 leading-relaxed">
                At TiaraLine Electric, we take pride in delivering exceptional electrical services that prioritize your safety, satisfaction, and peace of mind. Our commitment to quality and reliability has earned us a 5-star reputation throughout Wayne County.
              </p>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 bg-navy-900 hover:bg-navy-800 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
              >
                Get Started Today
              </a>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {whyChooseUs.map((item, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl p-6 shadow-sm border border-navy-100"
                >
                  <item.icon className="w-8 h-8 text-gold-500 mb-4" />
                  <h3 className="font-semibold text-navy-900 mb-1">{item.title}</h3>
                  <p className="text-navy-600 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-wider mb-3">Testimonials</span>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-navy-900 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-navy-600 max-w-2xl mx-auto">
              Don't just take our word for it – hear from homeowners and businesses who trust TiaraLine Electric.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-navy-50 rounded-2xl p-8 border border-navy-100"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-gold-400 fill-gold-400" />
                  ))}
                </div>
                <blockquote className="text-navy-700 mb-6 leading-relaxed">
                  "{testimonial.text}"
                </blockquote>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-navy-900 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-sm">
                      {testimonial.author.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <div className="font-semibold text-navy-900">{testimonial.author}</div>
                    <div className="text-navy-500 text-sm">{testimonial.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 lg:py-28 bg-navy-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <span className="inline-block text-gold-400 font-semibold text-sm uppercase tracking-wider mb-3">Contact Us</span>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-6">
                Get Your Free Estimate
              </h2>
              <p className="text-navy-300 mb-8 leading-relaxed">
                Ready to get started? Contact us today for a free, no-obligation estimate. We're here to answer your questions and provide the electrical solutions you need.
              </p>

              <div className="space-y-6">
                <a href="tel:7343733742" className="flex items-center gap-4 group">
                  <div className="bg-navy-800 group-hover:bg-gold-500 p-4 rounded-xl transition-colors">
                    <Phone className="w-6 h-6 text-gold-400 group-hover:text-navy-900 transition-colors" />
                  </div>
                  <div>
                    <div className="text-navy-400 text-sm">Call Us</div>
                    <div className="text-white font-semibold text-lg">(734) 373-3742</div>
                  </div>
                </a>

                <div className="flex items-center gap-4">
                  <div className="bg-navy-800 p-4 rounded-xl">
                    <MapPin className="w-6 h-6 text-gold-400" />
                  </div>
                  <div>
                    <div className="text-navy-400 text-sm">Location</div>
                    <div className="text-white font-medium">9235 Harrison St</div>
                    <div className="text-navy-300">Livonia, MI 48150</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 sm:p-8">
              {formSubmitted ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-display font-semibold text-xl text-navy-900 mb-2">Message Sent!</h3>
                  <p className="text-navy-600">Thank you for contacting us. We'll get back to you within 24 hours.</p>
                  <button
                    onClick={() => setFormSubmitted(false)}
                    className="mt-4 text-gold-600 font-medium hover:text-gold-700"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-navy-700 font-medium text-sm mb-1">Name</label>
                    <input
                      type="text"
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full border border-navy-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent outline-none transition-all"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="email" className="block text-navy-700 font-medium text-sm mb-1">Email</label>
                      <input
                        type="email"
                        id="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full border border-navy-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent outline-none transition-all"
                        placeholder="your@email.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-navy-700 font-medium text-sm mb-1">Phone</label>
                      <input
                        type="tel"
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full border border-navy-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent outline-none transition-all"
                        placeholder="(555) 555-5555"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-navy-700 font-medium text-sm mb-1">Message</label>
                    <textarea
                      id="message"
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full border border-navy-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent outline-none transition-all resize-none"
                      placeholder="Tell us about your project..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-navy-900 hover:bg-navy-800 text-white font-semibold px-6 py-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-950 border-t border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="bg-navy-800 p-2 rounded-lg">
                <Zap className="w-5 h-5 text-gold-400" />
              </div>
              <span className="font-display font-bold text-lg text-white">TiaraLine Electric</span>
            </div>

            <div className="text-navy-400 text-sm text-center">
              Proudly serving Livonia, MI and all of Wayne County
            </div>

            <div className="flex items-center gap-4 text-navy-400 text-sm">
              <a href="tel:7343733742" className="hover:text-gold-400 transition-colors">(734) 373-3742</a>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-navy-800 text-center text-navy-500 text-sm">
            © {new Date().getFullYear()} TiaraLine Electric. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
